<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Autisme</title>

<!-- Google fonts -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,700' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="css/style.css">

<!-- font awesome -->
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

<!-- bootstrap -->
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />

<!-- animate.css -->
<link rel="stylesheet" href="assets/animate/animate.css" />
<link rel="stylesheet" href="assets/animate/set.css" />

<!-- gallery -->
<link rel="stylesheet" href="assets/gallery/blueimp-gallery.min.css">

<!-- favicon -->
<link rel="shortcut icon" href="images/favicon.jpg" type="image/x-icon">
<link rel="icon" href="images/favicon.jpg" type="image/x-icon">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">



<link rel="stylesheet" href="assets/style.css">

</head>

<body>


<!-- Header Starts -->
<div class="navbar-wrapper">

  <nav class="navbar navbar-default navbar-expand-lg" role="navigation" id="top-nav">
    <div class="container">
      <div class="navbar-header">
        <!-- Logo Starts -->
        <a class="navbar-brand" href="#home"><img src="AutismeLogo.png" width="210px" height="50px"alt="logo"></a>
        <!-- #Logo Ends -->
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
      </div>
          <!-- Nav Starts -->
      <div class="navbar-collapse navthing collapse">
      
        <ul class="nav navbar-nav navbar-right">
          <?php include("./navigation.php"); ?>                
        </ul>
      </div>
    </div>
  </nav>

</div>
            <!-- #Nav Ends -->

          </div>
        </div>

      </div>
    </div>
<!-- #Header Starts -->




<div id="home">
<!-- Slider Starts -->

        <!-- #Item 1 -->

    




<!-- Cirlce Starts -->
<div id="about"  class="container spacer about">
<h2 class="text-center wowload fadeInUp">Wat is Autisme?</h2>  
  <div class="row">
  <div class="col-sm-6 wowload fadeInLeft">
    <h4>Wat is het precies?</h4>
    <p>Wat is nu precies autisme. Autisme wordt gezien als een pervasieve (diepe, doordringende) ontwikkelstoornis.
        
        Er zijn verschillende vormen van autisme die allen worden geschaard onder de term ” autismespectrumstoornis”. Waar het op neerkomt is dat autisme een stoornis is in de informatieverwerking van de hersenen. De informatie die in de hersenen binnenkomt wordt bij een autist op een andere manier verwerkt.
        
        Waar bij iemand die geen autisme heeft de input vanuit de zintuigen verwerkt wordt tot een samenhangend geheel heeft het autistisch brein het moeilijk om de details van deze input samen te brengen.
        
        Doordat deze input niet tot een samenhangend geheel kan worden gecombineerd hebben autisten vaak een probleem met de communicatie met anderen, veel moeite met sociale interactie en geen of weinig fantasie.
        
        De aandoening begint al vroeg, voor het derde levensjaar en heeft een negatieve invloed op de ontwikkeling van 3 vlakken of groepen. Deze 3 vlakken worden ook wel de autistische triade genoemd en vallen binnen het gebied van</p>
      
        1  Sociale interacties
        
        2 Taalontwikkeling
        
        3 Gedragsontwikkeling

  </div>
  <div class="col-sm-6 wowload fadeInRight">
  <h4>Wist u dat?</h4>
  <p>Wist u dat:
    
    meer dan 1 % van de nederlandse bevolking autisme heeft. In totaal zijn dat  ongeveer 190.000 mensen.
    
    autisme in 90 % van de gevallen een erfelijke aangelegenheid is en in slechts 10% van de gevallen het autisme te wijten is aan bijvoorbeeld problemen tijdens de zwangerschap en bevalling.
    
    15 -20% van de autisten naast autisme ook een verstandelijke beperking heeft
    
    Voordat de term “autismespectrumstoornis” gebruikt werd en alleen gediagnosticeerd werd op de vorm die we nu kennen als  “Klassiek autisme” werd er berekend dat 1 op 2200 mensen autisme had. Nu de term “autismespectrumstoornis” behoorlijk ingeburgerd is blijkt dat ongeveer 1 op de 300 mensen een vorm van autisme hebben.</p>

  </div>
  </div>

<br><br><br><br><br><br><br><br>



</div>

<!-- Footer Starts -->
<div class="footer text-center spacer">
<p class="wowload flipInX"><a href="#"><i class="fa fa-facebook fa-2x"></i></a> <a href="#"><i class="fa fa-dribbble fa-2x"></i></a> <a href="#"><i class="fa fa-twitter fa-2x"></i></a> <a href="#"><i class="fa fa-linkedin fa-2x"></i></a> </p>
Copyright 2018. All rights reserved.
</div>
<!-- # Footer Ends -->
<a href="#home" class="gototop "><i class="fa fa-angle-up  fa-3x"></i></a>





<!-- The Bootstrap Image Gallery lightbox, should be a child element of the document body -->
<div id="blueimp-gallery" class="blueimp-gallery blueimp-gallery-controls">
    <!-- The container for the modal slides -->
    <div class="slides"></div>
    <!-- Controls for the borderless lightbox -->
    <h3 class="title">title</h3>
    <a class="prev">‹</a>
    <a class="next">›</a>
    <a class="close">×</a>
    <!-- The modal dialog, which will be used to wrap the lightbox content -->    
</div>



<!-- jquery -->
<script src="assets/jquery.js"></script>

<!-- wow script -->
<script src="assets/wow/wow.min.js"></script>


<!-- boostrap -->
<script src="assets/bootstrap/js/bootstrap.js" type="text/javascript" ></script>

<!-- jquery mobile -->
<script src="assets/mobile/touchSwipe.min.js"></script>
<script src="assets/respond/respond.js"></script>

<!-- gallery -->
<script src="assets/gallery/jquery.blueimp-gallery.min.js"></script>

<!-- custom script -->
<script src="assets/script.js"></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  

    <script  src="js/index.js"></script>
</body>
</html>