<?php  
  if (isset($_SESSION["id"])) {

    switch($_SESSION["userrole"]) {
      case "subscriber":
        echo '<a href="./index.php?action=subscriber_home">Home</a> ';
        break;
      case "administrator":
        echo '<a href="./index.php?action=administrator_home">Administrator Home</a> ';
        echo '<a href="./index.php?action=sales_home">Sales Home</a> ';
        break;
        case "moderator":
        echo '<a href="./index.php?action=moderator_home"> moderator Home</a> ';
        break;
      case "superadmin":
        echo '<a href="./index.php?action=superadmin_home">Home</a> ';
        break;
      case "sales":
        echo '<a href="./index.php?action=sales_home">Sales Home</a> ';
        break;
      default:
        header("Location: ./index.php?action=home");
        break;
    }

    echo '<a href="./index.php?action=games">Games</a> ';    
    echo '<a href="./logout.php">Uitloggen</a> ';
  } else {
    echo '<li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>';
    echo '<li class="nav-item"><a class="nav-link" href="info.php">Wat is Autisme?</a></li>';
    echo '<li class="nav-item"><a class="nav-link" href="game.php">Game</a></li>';
    echo '<li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>';
    echo '<li class="nav-item"><a class="nav-link" href="./index.php?action=registerform&amp;status=register">Registreer</a></li> ';
    echo '<li class="nav-item"><a class="nav-link" href="./index.php?action=loginform&amp;status=login">Inloggen</a></li> ';
  }
?>