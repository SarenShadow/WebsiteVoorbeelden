$(document).ready(function(){
    $("#exampleModalCenter").modal("show");
  
    $(".modal-header").empty();
    $(".modal-body").html('Fijn dat uw er weer bent sales@gmail.com!');
    $(".modal-footer").empty();
  
    setTimeout(function () {
      window.location.replace("./index.php?action=sales-home");
    }, 3000)
  
  
  
  });