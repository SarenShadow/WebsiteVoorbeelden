$(document).ready(function () {
  $("#exampleModalCenter").modal("show");
  $(".modal-body").append('<div class="alert alert-info" role="alert">U heeft een van beide velden niet ingevuld! Probeer het opnieuw.</div>');
});