$(document).ready(function () {
  $("#exampleModalCenter").modal("show");
  $(".modal-body").append('<div class="alert alert-danger" role="alert">U logingegevens zijn niet correct. Probeer het opnieuw!</div>');
});