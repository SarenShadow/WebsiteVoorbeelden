$(document).ready(function() {
  // alert("Dit is een test");
  $("#exampleModalCenter").modal("show");
});