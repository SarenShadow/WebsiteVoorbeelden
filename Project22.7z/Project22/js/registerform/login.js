$(document).ready(function () {
  // alert("login test");
  $("#exampleModalCenter").modal("show");
});