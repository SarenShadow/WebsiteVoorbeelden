<?php
  $userrole = array("administrator", "superadmin");
 
  include("./security.php");
?>

<h1>Moderator Home</h1>

<script>
function myFunction() {
    var popup = document.getElementById("myPopup");
    popup.style.display = "block"; // Or whatever way you want to show it.
    setTimeout(function() {
        popup.style.display = "none"; //Or whatever way you want to hide it.
    }, 3000);}
</script> 

<?php
  if (isset($_SESSION["email"])) {
    echo "Welkom " . $_SESSION["email"];
  }
?>